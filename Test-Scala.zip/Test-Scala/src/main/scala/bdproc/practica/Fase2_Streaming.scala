

package bdproc.practica


import org.apache.spark.sql.SparkSession

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.sql.functions._

import java.util.regex.Pattern
import java.util.regex.Matcher
import java.text.SimpleDateFormat
import java.util.Locale

import org.apache.spark.sql.types._

import bdproc.common.Utilities._


object Fase2_Streaming {

  def main(args: Array[String]): Unit = {


    var limit = 1000 // Valor por defecto

    // Control de parametros de entrada
    if (args.length == 1)
      limit = args(0).toInt

    println(s"Limite de alarma:${limit}")

    //session spark
    val spark = SparkSession
      .builder
      .appName("Fase2_Streaming")
      .master("local[*]")
      .config("spark.sql.streaming.checkpointLocation", "file:///home/kc/Documentos/datasets/checkpoint")
      .getOrCreate()


    import spark.implicits._

    setupLogging()

    val jsonSchema = new StructType()
      .add("Location", "String")
      .add("Price_m2_Avg", "Float")

    val jsonDF = spark
      .readStream
      .schema(jsonSchema)
      .json("file:///home/kc/Documentos/datasets/real-estate")


    // Controlamos si alguna entrada supera el limite para enviarle un email
    // https://docs.databricks.com/user-guide/faq/send-email.html )
    val inputDF  = jsonDF.filter($"Price_m2_Avg" > limit)

    val consoleOutput = inputDF.writeStream.foreachBatch { (batchDF: DataFrame, batchId: Long) =>
      batchDF.show()
      // Envio de email
    }.start()

    /*
    val consoleOutput = inputDF
      .writeStream
      .outputMode("update")
      .format("console")
      .start()
    */

    val windowedData = jsonDF.groupBy($"Location", $"Price_m2_Avg")
                      .count().orderBy($"Price_m2_Avg".desc)

    println(s"Temporizando...")
    println(s"Puedes realizar cambios introduciendo nuevos ficheros en el directorio...")

    // Realizamos modificaciones manuales o mediante proceso en el directorio de carga
    Thread.sleep(5000)


    val query =  windowedData.writeStream.outputMode("complete")
      .format("console").start()


    //Esperamos finalización de los procesos
    //query.awaitTermination()
    spark.streams.awaitAnyTermination()


  }

}
