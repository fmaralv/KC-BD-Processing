package bdproc.practica


import org.apache.spark.sql.SparkSession

import bdproc.common.Utilities._


object Fase1_SQL {


  def main(args: Array[String]): Unit = {

    //session spark
    val spark = SparkSession
      .builder
      .appName("Fase1_SQL")
      .master("local[*]")
      .config("spark.sql.streaming.checkpointLocation", "file:///home/kc/Documentos/datasets/checkpoint")
      .getOrCreate()

    setupLogging()

    //Cargamos csv llamado RealState.csv
    val realstatesDF = spark.read
      .option("header",true)
      .option("sep",",")
      .option("inferschema",true)
      .csv("file:///home/kc/Documentos/datasets/RealEstate.csv").toDF("MLS","Location","Price","Bedrooms","Bathrooms","Size","Price_m2","Status")



    //Visualizamos el esquema obtenido
    realstatesDF.printSchema


    //creamos vista
    realstatesDF.createOrReplaceTempView("realstates")

    //spark.sql("select * from realstates limit 5").show


    // Obtenemos el valor del cambio via API para que sea mas realista
    val exchangevalue = getExchangeValue

    println(s"Valor del cambio:${exchangevalue}")

    // Convertimos a mayusculas y quitamos espacios para evitar inconsistencia de datos
    // Aplicamos la convertion sobre los resultados de la Query por motivos de rendimiento

    /*
    val dataDF =spark.sql(s"""select trim(upper(Location)) as Location , (avg(Price_m2)/${exchangevalue}) as Price_m2_Avg from realstates
                                      group by Location order by  Location asc""")
    */

    val dataDF =spark.sql(s"""select trim(upper(Location)) as Location , (avg(Price_m2)/${exchangevalue}) as Price_m2_Avg from realstates
                                      group by Location""")

    dataDF.coalesce(1).write.json("file:///home/kc/Documentos/datasets/real-estate")

  }

}
