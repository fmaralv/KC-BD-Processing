package bdproc.practica

import bdproc.common.Utilities.setupLogging
import org.apache.spark.mllib.classification.LogisticRegressionModel
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.optimization.{LBFGS, LogisticGradient, SquaredL2Updater}
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.{LabeledPoint, StreamingLinearRegressionWithSGD}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.streaming.{Seconds, StreamingContext}

import scala.collection.mutable

object Fase3_ML {

  def main(args: Array[String]): Unit = {

    //session spark
    val spark = SparkSession
      .builder
      .appName("Fase3_ML")
      .master("local[*]")
      .config("spark.executor.memory","2g")
      .getOrCreate()

    import spark.implicits._

    setupLogging()

    val ssc = new StreamingContext(spark.sparkContext, Seconds(2))

    val rawDF = spark.read
      .format("com.databricks.spark.csv")
      .option("inferSchema","true")
      .option("header",true)
      .option("delimiter",",")
      .load("file:///home/kc/Documentos/datasets/RealEstate.csv")

    val rdd = rawDF.rdd.zipWithUniqueId()

    // Visualizar contenido
    //rdd.collect().foreach(println)

    //MAP o diccionario (local) con los valores que indican el precio final
    val lookupQuality = rdd.map{ case (r: Row, id: Long)=> (id, r.getInt(2))}
      .collect().toMap

    //crear un conjunto de features
    //val d = rdd.map{case (r: Row, id: Long)
    //=> LabeledPoint(id, Vectors.dense(r.getString(1),r.getInt(5))) }


    // Da problemas con el casting :-(

    val d = rdd.map{case (r: Row, id: Long)
    => val doubleArray = Array(r.getString(1).toDouble,r.getInt(5).toDouble)
      LabeledPoint(id, Vectors.dense(doubleArray)) }


    //conjuntos de entrenamiento y test
    val trainQ = new mutable.Queue[RDD[LabeledPoint]]()
    val testQ = new mutable.Queue[RDD[LabeledPoint]]()

    //creacion de modelo
    val trainingStream = ssc.queueStream(trainQ)
    val testStream = ssc.queueStream(testQ)

   //todo: rellenar colas


    val model = new StreamingLinearRegressionWithSGD()
      .setInitialWeights(Vectors.zeros(2)) // num. features
      .setNumIterations(25)
      .setStepSize(0.1)
      .setMiniBatchFraction(0.25)

    //entrenar modelo
    model.trainOn(trainingStream)
    val result = model.predictOnValues(testStream.map(lp => (lp.label, lp.features)))
    result.map{ case (id: Double, prediction: Double) =>
      (id, prediction, lookupQuality(id.asInstanceOf[Long])) }
      .print()

    ssc.start


    //reparticion d datos entre conjunto de entrenamiento (80%) y de validacion (20%)
    val Array(trainData, test) = d.randomSplit(Array(.80, .20))

    trainQ +=  trainData
    Thread.sleep(4000) //esperamos cuatro segundos

    //reparticion d datos de test en dos conjuntos iguales (al 50%)
    val testGroups = test.randomSplit(Array(.50, .50))
    testGroups.foreach(group => {
      testQ += group

      Thread.sleep(2000) //esperamos dos segundos
    })

    ssc.stop()

  }



}
