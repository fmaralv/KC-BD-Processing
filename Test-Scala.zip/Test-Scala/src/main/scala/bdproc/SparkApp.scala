package bdproc

object SparkApp {

  //driver program (test)
  def main(args: Array[String]): Unit = {
    println("A tope con Scala-Spark!!")
  }
}
