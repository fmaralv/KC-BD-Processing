package bdproc.spark_graphx

import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.graphx.{Edge, Graph, VertexId}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object GraphSpark {

  val Amigo = "amigo"
  val Seguidor = "seguidor"

  type NombreUsuario = String
  type Relacion = String

  def main(args: Array[String]): Unit = {

    Logger.getRootLogger().setLevel(Level.ERROR)

    val spark = SparkSession.builder().master("local[2]").getOrCreate().sparkContext
    val grafo = construirGrafo(spark)

    val usersWithoutAnyFriend = buscarUsuariosSinAmigos(grafo)
    println(s"Usuarios sin amigos: $usersWithoutAnyFriend")

    val usuariosConUnNumeroDeAmigosSospechoso = buscarUsuariosComDemasiadosAmigos(grafo, 5)
    println(s"Usuarios con amigos ficticios (anomalia): $usuariosConUnNumeroDeAmigosSospechoso")

  }

  def construirGrafo(spark: SparkContext): Graph[(NombreUsuario), Relacion] = {

    val users: RDD[(VertexId, NombreUsuario)] =
      spark.parallelize(Array(
        (1L, "Juan"),
        (2L, "Maria"),
        (3L, "Alberto"),
        (4L, "Luis"),
        (5L, "Ana"),
        (6L, "Jose"),
        (7L, "Ricardo"),
      ))

    val relationships: RDD[Edge[String]] =
      spark.parallelize(Array(
        Edge(1L, 2L, Amigo),
        Edge(2L, 3L, Amigo),
        Edge(4L, 5L, Amigo),
        Edge(6L, 7L, Amigo),
        Edge(6L, 5L, Amigo),
        Edge(6L, 4L, Amigo),
        Edge(6L, 3L, Amigo),
        Edge(6L, 2L, Amigo),
        Edge(6L, 7L, Amigo),
        Edge(2L, 4L, Seguidor),
        Edge(2L, 7L, Seguidor),
        Edge(1L, 5L, Seguidor)
      ))

    Graph(users, relationships)
  }

  def buscarUsuariosSinAmigos(graph: Graph[(NombreUsuario), Relacion]): List[VertexId] = {
    graph
      .connectedComponents
      .vertices
      .map(_.swap)
      .groupByKey()
      .filter { case (vertexId, iterable) => iterable.size == 1 }
      .map(_._1)
      .collect()
      .toList
  }

  def buscarUsuariosComDemasiadosAmigos(graph: Graph[NombreUsuario, Relacion],
                                    maxNUmAmigosPermitidos: Int): List[VertexId] = {

    graph
      .edges
      .filter(_.attr == Amigo)
      .groupBy(_.srcId)
      .filter(_._2.size >= maxNUmAmigosPermitidos)
      .map(_._1)
      .collect()
      .toList
  }


}
