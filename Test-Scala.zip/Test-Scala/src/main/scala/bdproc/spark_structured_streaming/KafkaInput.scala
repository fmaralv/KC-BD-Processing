package bdproc.spark_structured_streaming


import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe

import java.util.regex.Pattern
import java.util.regex.Matcher

import bdproc.common.Utilities._

object KafkaInput {

  def main(args: Array[String]): Unit = {



    //todo: creamos la sesion spark
    val spark = SparkSession.builder
        .appName("Kafka Input")
        .master("local[*]")
        .config("spark.sql.streaming.checkpointLocation","file:///home/kc/Documentos/datasets/checkpoint")
        .getOrCreate


    //todo: creamos el contexto (streaming)
    val ssc = new StreamingContext(spark.sparkContext,Seconds(1))


    //seteamos sistema logging (ver paquete common)
    setupLogging()


    //inicializamos patrones de busqueda agrupados (ver common) para el fichero access_log.txt
    val pattern = apacheLogPattern()

    //todo:configuracion kafka
    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> "localhost:9092",
      "group.id" -> "1",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "auto.offset.reset" -> "latest",
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )

    //todo: creacion de topics : Sólo keepcoding
    val topics = Array("keepcoding")


    //todo: creación de stream directo sobre kafka
    val lines = KafkaUtils.createDirectStream[String,String](
          ssc,PreferConsistent,Subscribe[String,String](topics, kafkaParams))
                                                                .map(reg => reg.value)



    //todo: extraemos el campo de petición de recurso de cada linea del log
    val requests = lines.map(x => {
                        val matcher:Matcher = pattern.matcher(x);
                        if (matcher.matches()) matcher.group(5)
    })


    //todo: extraemos la url de dicha petición
    val urls = requests.map(x => {
      val arr = x.toString().split(" ");
      if (arr.size == 3) arr(1) else "[error]"
    })


    //todo: restringimos la info a una ventana temporal de 5 minutos
    val urlCounts = urls.map(x => (x,1)).reduceByKeyAndWindow(_+_, _-_, Seconds(300),Seconds(1))
    //DStream

    //todo:Presentación delos resultados (ordenados)
    val sortedResults = urls.transform(rdd => rdd.sortBy(x => x, false))
    sortedResults.print()


    //todo: lanzamos el proceso de escucha del stream con un punto de salaguarda (checkpoint)
    ssc.start()
    ssc.awaitTermination()

  }
}
